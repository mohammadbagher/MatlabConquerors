function sketch( plot_axes, play, puase, next, previous )
%UNTITLED4 Summary of this function goes here
%   Detailed explanation goes here


end

