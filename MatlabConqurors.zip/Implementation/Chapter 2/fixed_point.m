function root = fixed_point( func, a, b, max_step, tol )
%UNTITLED Summary of this function goes here
%   Detailed explanation goes here


end

