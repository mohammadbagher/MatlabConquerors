%script called when play button is pressed in sketching figure 
% ChapterTwoAnswer.fig
pause=0;
while pause==0,
    current_step = current_step +1;
    %update graph
    
    
    %update current step
    
    
    
end
current_step = current_step - 1;