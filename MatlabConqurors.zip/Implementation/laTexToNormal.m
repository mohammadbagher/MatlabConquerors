function [output_str]= laTexToNormal(input_str)
output_str=input_str;