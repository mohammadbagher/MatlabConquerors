function []= Interpolate (x)
x