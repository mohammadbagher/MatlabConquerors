function []=Curvfitting(y)
y
